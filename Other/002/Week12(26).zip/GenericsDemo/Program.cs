﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Display<int>(123);
            //Display<string>("Narendra");
            //int a = 3, b = 10;
            //Console.WriteLine($"a:{a} b:{b}");
            //Swap<int>(ref a, ref b);
            //Console.WriteLine($"a:{a} b:{b}");
            //string[] ans =  MakeArray<string>(5, "Da Hee");
            //Console.WriteLine(string.Join(", ", ans));

            Generic1<int> obj1 = new Generic1<int>(123);
            Console.WriteLine(obj1.Value);
            Generic1<Person> obj2 = new Generic1<Person>(new Person() { Name = "Gerald", NumberOfCourses = 7 });
            Console.WriteLine($"{obj2.Value.Name} ({obj2.Value.NumberOfCourses})");

            Generic2<double> obj3 = new Generic2<double>();
            obj3.Show(Math.PI);
        }
        static void Display<T>(T value)
        {
            Console.WriteLine(value);
        }
        static void Swap<T>(ref T first, ref T second)
        {
            T temp = first;
            first = second;
            second = temp;
        }
        static T[] MakeArray<T>(int size, T value)
        {
            T[] result = new T[size];
            for (int i = 0; i < size; i++)
                result[i] = value;

            return result;
        }
    }
    class Generic1<U>
    {
        public U Value { get; }
        public Generic1(U value)
        { Value = value; }
    }
    class Person
    {
        public string Name { get; set; }
        public int NumberOfCourses { get; set; }
    }
    interface IShowable<T>
    {
        void Show(T value);
    }
    class Generic2<T> : IShowable<T>
    {
        public void Show(T value) => Console.WriteLine(value);
    }
}
