﻿using System;
//using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab25
{
    class Program
    {
        static void Main(string[] args)
        {
            LinkedList<string> poem = new LinkedList<string>("Mary had a little lamb, its fleeee was as white as snow".Split());
            foreach (var item in poem.Items)
                Console.Write(item + " ");
        }
    }

    class Node<T>
    {
        public T Data { get; }
        public Node<T> Next { get; set; }
        public Node(T data)
        {
            Data = data;
        }   
    }
    class LinkedList<T>
    {
        public Node<T> Root { get; }
        public Node<T> Current { get; set; }
        public LinkedList(Node<T> node)
        {
            Root = node; Current = node;
        }
        public void Add(Node<T> node)
        {
            Current.Next = node;
            Current = node;
        }
        public void Add(T data)
        {
            Add(new Node<T>(data));
        }
        public void Add(T[] data)
        {
            foreach(T dat in data)
                Add(new Node<T>(dat));
        }

        public LinkedList(T[] data)
            :this(new Node<T>(data[0]))
        {
            for (int i = 1; i < data.Length; i++)
            {
                Add(new Node<T>(data[i]));
            }
        }
        public System.Collections.Generic.IEnumerable<T> Items
        {
            get
            {
                Node<T> present = Root;
                while (present != null)
                {
                    yield return present.Data;
                    present = present.Next;
                }
            }
        }
    }
}
